# Rotten Apple Labeller > Rotten Apples
https://universe.roboflow.com/shyam-krishna/rotten-apple-labeller

Provided by a Roboflow user
License: CC BY 4.0

